
// sudo ./example 1133 2085

#include <libusb-1.0/libusb.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>  // for strtol
#include <errno.h>


int fdnum_yuv;
int fdnum_bgr;


long vidi;
long pidi;
char* tmpptr;


unsigned int width_p;
unsigned int height_p;
int fmt_index;
int frame_index;

/** Converts an unaligned four-byte little-endian integer into an int32 */
#define DW_TO_INT(p) ((p)[0] | ((p)[1] << 8) | ((p)[2] << 16) | ((p)[3] << 24))

/** VideoStreaming interface descriptor subtype (A.6) */
enum uvc_vs_desc_subtype {
  UVC_VS_UNDEFINED = 0x00,
  UVC_VS_INPUT_HEADER = 0x01,
  UVC_VS_OUTPUT_HEADER = 0x02,
  UVC_VS_STILL_IMAGE_FRAME = 0x03,
  UVC_VS_FORMAT_UNCOMPRESSED = 0x04,
  UVC_VS_FRAME_UNCOMPRESSED = 0x05,
  UVC_VS_FORMAT_MJPEG = 0x06,
  UVC_VS_FRAME_MJPEG = 0x07,
  UVC_VS_FORMAT_MPEG2TS = 0x0a,
  UVC_VS_FORMAT_DV = 0x0c,
  UVC_VS_COLORFORMAT = 0x0d,
  UVC_VS_FORMAT_FRAME_BASED = 0x10,
  UVC_VS_FRAME_FRAME_BASED = 0x11,
  UVC_VS_FORMAT_STREAM_BASED = 0x12
};





static struct libusb_device_handle *dev_handle = NULL;
static struct libusb_device *usb_dev = NULL;

int main(int argc, char **argv){


    vidi = strtol(argv[1],tmpptr,10);
    pidi = strtol(argv[2],tmpptr,10);

    //fmt_index = strtol(argv[3],tmpptr,10);
    //frame_index = strtol(argv[4],tmpptr,10);


    int rc;
    rc = libusb_init(NULL);
    if (rc < 0) {
        fprintf(stderr, "Error initializing libusb: %s\n", libusb_error_name(rc));
        exit(1);
    }

    dev_handle = libusb_open_device_with_vid_pid(NULL, vidi, pidi);

    if (!dev_handle) {
        fprintf(stderr, "Error finding USB device\n");
        goto out;
    }


    usb_dev = libusb_get_device(dev_handle) ;

    // https://www.beyondlogic.org/usbnutshell/usb5.shtml
    // USB devices can only have one device descriptor. 
    

    struct libusb_device_descriptor desc;

    if ( libusb_get_device_descriptor ( usb_dev, &desc ) != LIBUSB_SUCCESS ){
        fprintf(stderr, "Error getting Device Descriptor\n");
        goto out;
    }


    printf("desc.bLength: %d\n", desc.bLength);
    printf("desc.bDescriptorType: %d\n", desc.bDescriptorType);
    printf("desc.bcdUSB: %d\n", desc.bcdUSB);
    printf("desc.bDeviceClass: %d\n", desc.bDeviceClass);
    printf("desc.bDeviceSubClass: %d\n", desc.bDeviceSubClass);
    printf("desc.bDeviceProtocol: %d\n", desc.bDeviceProtocol);
    printf("desc.bMaxPacketSize0: %d\n", desc.bMaxPacketSize0);
    printf("desc.idVendor: %d\n", desc.idVendor);
    printf("desc.idProduct: %d\n", desc.idProduct);
    printf("desc.bcdDevice: %d\n", desc.bcdDevice);
    printf("desc.iManufacturer: %d\n", desc.iManufacturer);
    printf("desc.iProduct: %d\n", desc.iProduct);
    printf("desc.iSerialNumber: %d\n", desc.iSerialNumber);
    printf("desc.bNumConfigurations: %d\n", desc.bNumConfigurations);


    // https://www.beyondlogic.org/usbnutshell/usb5.shtml
    // The configuration descriptor specifies values such as 
    // the amount of power this particular configuration uses, 
    // if the device is self or bus powered and the number of interfaces it has. 
    // When a device is enumerated, the host reads the device descriptors 
    // and can make a decision of which configuration to enable. 
    // It can only enable one configuration at a time.


    printf("===================================\n");
    printf("===================================\n");


    struct libusb_config_descriptor *config;

    if (libusb_get_config_descriptor(usb_dev, 0, &config) != 0){
        fprintf(stderr, "Error getting Config Descriptor\n");
        goto out;
    }


    printf("config->bLength: %d\n", config->bLength);
    printf("config->bDescriptorType: %d\n", config->bDescriptorType);
    printf("config->wTotalLength: %d\n", config->wTotalLength);
    printf("config->bNumInterfaces: %d\n", config->bNumInterfaces);
    printf("config->bConfigurationValue: %d\n", config->bConfigurationValue);
    printf("config->iConfiguration: %d\n", config->iConfiguration);
    printf("config->bmAttributes: %d\n", config->bmAttributes);
    printf("config->MaxPower: %d\n", config->MaxPower);

    /** Array of interfaces supported by this configuration. The length of
     * this array is determined by the bNumInterfaces field. */
    printf("config->interface: %p\n", config->interface);

	/** Extra descriptors. If libusb encounters unknown configuration
	 * descriptors, it will store them here, should you wish to parse them. */
    printf("config->extra: %p\n", config->extra);


    /** Length of the extra descriptors, in bytes. Must be non-negative. */
    printf("config->extra_length: %d\n", config->extra_length);


    printf("===================================\n");
    printf("===================================\n");


    /* per interface */
    uint8_t got_interface = 0;
    int interface_idx;
    const struct libusb_interface *interface;

      /* per altsetting */
    int altsetting_idx;
    const struct libusb_interface_descriptor *if_desc;


      /* per endpoint */
    int endpoint_idx;
    const struct libusb_endpoint_descriptor *ep_desc;


    for (interface_idx = 0; !got_interface && interface_idx < config->bNumInterfaces; ++interface_idx) {

        interface = &config->interface[interface_idx];

        printf("------------------------\n");
        printf("INTERFACE: %d \n", interface_idx);


        /** Array of interface descriptors. The length of this array is determined
         * by the num_altsetting field. */
        printf("interface->altsetting: %p\n", interface->altsetting);
        printf("interface->num_altsetting: %d\n", interface->num_altsetting);


        for (altsetting_idx = 0; !got_interface && altsetting_idx < interface->num_altsetting; ++altsetting_idx) {

            if_desc = &interface->altsetting[altsetting_idx];

            printf("------------------------\n");
            printf("INTERFACE: %d, ALTSETTING(if_desc): %d\n", interface_idx, altsetting_idx); 

            printf("if_desc->bLength: %d\n", if_desc->bLength);
            printf("if_desc->bDescriptorType: %d\n", if_desc->bDescriptorType);
            printf("if_desc->bInterfaceNumber: %d\n", if_desc->bInterfaceNumber);
            printf("if_desc->bAlternateSetting: %d\n", if_desc->bAlternateSetting);
            printf("if_desc->bNumEndpoints: %d\n", if_desc->bNumEndpoints);
            printf("if_desc->bInterfaceClass: %d\n", if_desc->bInterfaceClass);
            printf("if_desc->bInterfaceSubClass: %d\n", if_desc->bInterfaceSubClass);
            printf("if_desc->bInterfaceProtocol: %d\n", if_desc->bInterfaceProtocol);
            printf("if_desc->iInterface: %d\n", if_desc->iInterface);

            /** Array of endpoint descriptors. This length of this array is determined
            * by the bNumEndpoints field. */
            printf("if_desc->endpoint: %p\n", if_desc->endpoint);

            /** Extra descriptors. If libusb encounters unknown interface descriptors,
	        * it will store them here, should you wish to parse them. */
            printf("if_desc->extra: %p\n", if_desc->extra);
            /** Length of the extra descriptors, in bytes. Must be non-negative. */
            printf("if_desc->extra_length: %d\n", if_desc->extra_length);    


            if (if_desc->extra_length > 0){

                printf("--------EXTRA INTERFACES: INTERFACE: %d, ALTSETTING(if_desc): %d--------\n", interface_idx, altsetting_idx);

                unsigned char *buffer = if_desc->extra;
                size_t buffer_left = if_desc->extra_length;
                size_t block_size;
                int descriptor_subtype;

                while (buffer_left >= 3) {

                    block_size = buffer[0];
                    printf("block_size: %d\n", block_size);
                    printf("buffer_left: %d\n", buffer_left);


                    descriptor_subtype = buffer[2];
                    printf("descriptor_subtype: %d\n", descriptor_subtype);


                    switch (descriptor_subtype) {

                        case UVC_VS_INPUT_HEADER:
                            printf("UVC_VS_INPUT_HEADER\n");
                            printf("uvc_parse_vs_input_header(stream_if, buffer, block_size); \n");
                            break;
                        case UVC_VS_OUTPUT_HEADER:
                            printf("unsupported descriptor subtype VS_OUTPUT_HEADER\n");
                            break;
                        case UVC_VS_STILL_IMAGE_FRAME:
                            printf("UVC_VS_STILL_IMAGE_FRAME\n");
                            printf("uvc_parse_vs_still_image_frame(stream_if, block, block_size);\n");
                            break;
                        case UVC_VS_FORMAT_UNCOMPRESSED:

                            // https://learn.microsoft.com/en-us/windows-hardware/drivers/stream/uvc-camera-implementation-guide
                            printf("-----------UVC_VS_FORMAT_UNCOMPRESSED-----------\n");
                            printf("uvc_parse_vs_format_uncompressed(stream_if, block, block_size);\n");

                            printf("bDescriptorSubtype = buffer[2]: %d\n", buffer[2]);
                            printf("bFormatIndex = buffer[3]: %d\n", buffer[3]);
                            printf("bBitsPerPixel = buffer[21]: %d\n", buffer[21]);
                            printf("bBitsPerPixel = buffer[21]: %d\n", buffer[21]);
                            printf("bDefaultFrameIndex = buffer[22]: %d\n", buffer[22]);
                            printf("bAspectRatioX = buffer[23]: %d\n", buffer[23]);
                            printf("bAspectRatioY = buffer[24]: %d\n", buffer[24]);

                            printf("-----------END UVC_VS_FORMAT_UNCOMPRESSED-----------\n");


                            break;
                        case UVC_VS_FORMAT_MJPEG:
                            printf("UVC_VS_FORMAT_MJPEG\n");
                            printf("uvc_parse_vs_format_mjpeg(stream_if, block, block_size);\n");
                            break;
                        case UVC_VS_FRAME_UNCOMPRESSED:
                            printf("UVC_VS_FRAME_UNCOMPRESSED\n");
                        case UVC_VS_FRAME_MJPEG:
                            printf("UVC_VS_FRAME_MJPEG\n");
                            printf("uvc_parse_vs_frame_uncompressed(stream_if, block, block_size);\n");

                            printf("-----------UVC_VS_FRAME_UNCOMPRESSED && UVC_VS_FRAME_MJPEG -----------\n");

                            printf("bDescriptorSubtype = buffer[2]: %d\n", buffer[2]);
                            printf("bFrameIndex = buffer[3]: %d\n", buffer[3]);
                            printf("bmCapabilities = buffer[4]: %d\n", buffer[4]);
                            printf("wWidth = buffer[5] + (buffer[6] << 8): %d\n", buffer[5] + (buffer[6] << 8));
                            printf("wHeight = buffer[7] + (buffer[8] << 8): %d\n", buffer[7] + (buffer[8] << 8));

                            printf("dwMinBitRate = DW_TO_INT(&buffer[9]): %d\n", DW_TO_INT(&buffer[9]));
                            printf("dwMaxBitRate = DW_TO_INT(&buffer[13]): %d\n", DW_TO_INT(&buffer[13]));

                            printf("dwMaxVideoFrameBufferSize = DW_TO_INT(&buffer[17]): %d\n", DW_TO_INT(&buffer[17]));
                            printf("dwDefaultFrameInterval = DW_TO_INT(&buffer[21]): %d\n", DW_TO_INT(&buffer[21]));

                            printf("bFrameIntervalType = buffer[25]: %d\n", buffer[25]);

                            printf("-----------END UVC_VS_FRAME_UNCOMPRESSED && UVC_VS_FRAME_MJPEG-----------\n");

                            break;
                        case UVC_VS_FORMAT_MPEG2TS:
                            printf("unsupported descriptor subtype VS_FORMAT_MPEG2TS\n");
                            break;
                        case UVC_VS_FORMAT_DV:
                            printf("unsupported descriptor subtype VS_FORMAT_DV\n");
                            break;
                        case UVC_VS_COLORFORMAT:
                            printf("unsupported descriptor subtype VS_COLORFORMAT\n");
                            break;
                        case UVC_VS_FORMAT_FRAME_BASED:
                            printf("UVC_VS_FORMAT_FRAME_BASED\n");
                            printf("uvc_parse_vs_frame_format ( stream_if, block, block_size );\n");
                            break;
                        case UVC_VS_FRAME_FRAME_BASED:
                            printf("-----------UVC_VS_FRAME_FRAME_BASED-----------\n");
                            printf("uvc_parse_vs_frame_frame ( stream_if, block, block_size );\n");

                            printf("bDescriptorSubtype = buffer[2]: %d\n", buffer[2]);
                            printf("bFrameIndex = buffer[3]: %d\n", buffer[3]);
                            printf("bmCapabilities = buffer[4]: %d\n", buffer[4]);
                            printf("wWidth = buffer[5] + (buffer[6] << 8): %d\n", buffer[5] + (buffer[6] << 8));
                            printf("wHeight = buffer[7] + (buffer[8] << 8): %d\n", buffer[7] + (buffer[8] << 8));

                            printf("dwMinBitRate = DW_TO_INT(&buffer[9]): %d\n", DW_TO_INT(&buffer[9]));
                            printf("dwMaxBitRate = DW_TO_INT(&buffer[13]): %d\n", DW_TO_INT(&buffer[13]));
                            printf("dwDefaultFrameInterval = DW_TO_INT(&buffer[17]): %d\n", DW_TO_INT(&buffer[17]));
                            printf("bFrameIntervalType = buffer[21]: %d\n", buffer[21]);
                            printf("dwBytesPerLine = DW_TO_INT(&buffer[22]): %d\n", DW_TO_INT(&buffer[22]));

                            printf("-----------END UVC_VS_FRAME_FRAME_BASED-----------\n");

                            break;
                        case UVC_VS_FORMAT_STREAM_BASED:
                            printf("unsupported descriptor subtype VS_FORMAT_STREAM_BASED\n");
                            break;
                        default:
                            /** @todo handle JPEG and maybe still frames or even DV... */
                            //UVC_DEBUG("unsupported descriptor subtype: %d",descriptor_subtype);
                            printf("unsupported descriptor subtype: %d\n", descriptor_subtype);
                            break;


                    }

                    buffer_left -= block_size;
                    buffer += block_size;  

                    printf("------END EXTRA INTERFACE------\n");                  

                }

                printf("--------END EXTRA INTERFACES--------\n");

            }



            // for (endpoint_idx = 0;  endpoint_idx < if_desc->bNumEndpoints; ++endpoint_idx) {

            //     ep_desc = &if_desc->endpoint[endpoint_idx];


            //     printf("------------------------\n");
            //     printf("INTERFACE: %d, ALTSETTING(if_desc): %d, ENDPOINT: endpoint_idx %d\n", interface_idx, altsetting_idx, endpoint_idx); 

            //     printf("ep_desc->bLength: %d\n", ep_desc->bLength);
            //     printf("ep_desc->bDescriptorType: %d\n", ep_desc->bDescriptorType);
            //     printf("ep_desc->bEndpointAddress: %d\n", ep_desc->bEndpointAddress);
            //     printf("ep_desc->bmAttributes: %d\n", ep_desc->bmAttributes);
            //     printf("ep_desc->wMaxPacketSize: %d\n", ep_desc->wMaxPacketSize);
            //     printf("ep_desc->bInterval: %d\n", ep_desc->bInterval);
            //     printf("ep_desc->bRefresh: %d\n", ep_desc->bRefresh);
            //     printf("ep_desc->bSynchAddress: %d\n", ep_desc->bSynchAddress);

            //     /** Extra descriptors. If libusb encounters unknown endpoint descriptors,
            //      * it will store them here, should you wish to parse them. */  
            //     printf("ep_desc->extra: %p\n", ep_desc->extra);
            //     /** Length of the extra descriptors, in bytes. Must be non-negative. */
            //     printf("ep_desc->extra_length: %d\n", ep_desc->extra_length);                


            //     // for (int extra_enpoint_idx = 0; extra_enpoint_idx < ep_desc->extra_length; ++extra_enpoint_idx){
            //     //     printf("-----------------extra_enpoint------------------\n");
            //     //     //printf("%s\n", ep_desc->extra[extra_enpoint_idx]);



            //     //     break;
            //     // }


            //     printf("------\n");

            // }

        }

        printf("------------------------\n");

    }

    printf("hello\n");


out:
    if (dev_handle)
        libusb_close(dev_handle);
    libusb_exit(NULL);
    return rc;

}





// There are types of descriptors. They are different for different types of devices.
// When libusb parses handles, it only understands handle types that are present on all USB devices.
// If they are descriptors specific to device types (HID, UVC, etc...), then libusb requires you to parse them yourself based on the specifications.
// This is exactly what the "libuvc" library does. This library parses UVC device-specific descriptors.

// My "libusb" example does this without using "libuvc" (of course I looked at the code there).


// It remains to parse the endpoints.

// Then, I can tell the "libusb" library the parameters (interface number and endpoint number) to get the video stream from the device.


// The advantage of this approach is that later, it will be easier to understand what is going on in the kernel.