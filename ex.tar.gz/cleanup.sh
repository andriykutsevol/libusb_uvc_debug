#!/bin/bash
set -e


find ./aver -type f -exec rm -ivf {} \;
find ./google -type f -exec rm -ivf {} \;
find ./c270 -type f -exec rm -ivf {} \;
