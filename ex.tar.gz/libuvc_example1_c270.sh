#!/bin/bash
set -e


output_dir=`pwd`"/c270/libuvc/1"

./LIBUVC_EXAMPLES_EX.sh 1 1133 2085 video0 640 480 0 0 15 ${output_dir}


./LIBUVC_EXAMPLES_EX.sh 1 1133 2085 video0 1280 720 0 17 15 ${output_dir}